/* @section: article-page */
import { useParams, Link, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, BookOpen, User, Tag, Share2, ExternalLink } from "lucide-react";
import { getArticleBySlug, articles } from "@/data/articles";
import ArticleCard from "@/components/ArticleCard";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.08, ease: [0.25, 0.1, 0.25, 1] },
  }),
};

export default function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const article = slug ? getArticleBySlug(slug) : undefined;

  if (!article) return <Navigate to="/" replace />;

  const related = articles
    .filter(
      (a) =>
        a.id !== article.id &&
        (a.metadata.characters.some((c) =>
          article.metadata.characters.includes(c)
        ) ||
          a.metadata.categories.some((c) =>
            article.metadata.categories.includes(c)
          ))
    )
    .slice(0, 3);

  return (
    <div className="min-h-screen">
      {/* @section: article-hero */}
      <div className="relative">
        {article.image && (
          <div className="absolute inset-0 h-64 sm:h-80">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/40 to-background" />
          </div>
        )}
        <div className="relative z-10 px-4 lg:px-12 pt-10 pb-8">
          <div className="max-w-4xl mx-auto">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8 group"
            >
              <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform" />
              Voltar ao arquivo
            </Link>

            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground/60 mb-5">
              <Link to="/" className="hover:text-primary transition-colors">Início</Link>
              <span>/</span>
              {article.metadata.categories[0] && (
                <>
                  <Link
                    to={`/${article.metadata.categories[0]}s`}
                    className="hover:text-primary transition-colors capitalize"
                  >
                    {article.metadata.categories[0]}s
                  </Link>
                  <span>/</span>
                </>
              )}
              <span className="text-muted-foreground line-clamp-1">{article.title}</span>
            </div>

            {/* Article header */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1
                className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4 leading-tight"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                {article.title}
              </h1>
              {article.subtitle && (
                <p className="text-base text-muted-foreground mb-6">{article.subtitle}</p>
              )}
              <p className="text-muted-foreground leading-relaxed text-base max-w-2xl">
                {article.excerpt}
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* @section: article-body */}
      <div className="px-4 lg:px-12 pb-16">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-[1fr_280px] gap-10">
            {/* Main content */}
            <div className="space-y-10 min-w-0">

              {/* Info box */}
              {(article.metadata.anime || article.metadata.manga) && (
                <motion.div
                  custom={0}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  className="bg-card border border-border rounded-xl overflow-hidden"
                >
                  <div className="px-5 py-3 border-b border-border bg-muted/30">
                    <span
                      className="text-xs font-bold tracking-widest text-muted-foreground uppercase"
                      style={{ fontFamily: "'Cinzel', serif" }}
                    >
                      Informações
                    </span>
                  </div>
                  <div className="p-5 grid sm:grid-cols-2 gap-4">
                    {article.metadata.anime && (
                      <div>
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-1">Anime</span>
                        <span className="text-sm font-medium text-foreground">{article.metadata.anime}</span>
                      </div>
                    )}
                    {article.metadata.episode !== undefined && (
                      <div>
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-1">Episódio</span>
                        <span className="text-sm font-bold text-primary font-mono">{article.metadata.episode}</span>
                      </div>
                    )}
                    {article.metadata.timestamp && (
                      <div>
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-1">Minutagem</span>
                        <span className="text-sm font-bold text-primary font-mono">{article.metadata.timestamp}</span>
                        <span className="text-xs text-muted-foreground/50 block mt-0.5">(versão disponível na Netflix)</span>
                      </div>
                    )}
                    {article.metadata.manga && (
                      <div>
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-1">Mangá</span>
                        <span className="text-sm font-medium text-foreground">{article.metadata.manga}</span>
                      </div>
                    )}
                    {article.metadata.chapter !== undefined && (
                      <div>
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-1">Capítulo</span>
                        <span className="text-sm font-bold text-primary font-mono">{article.metadata.chapter}</span>
                      </div>
                    )}
                    {article.metadata.characters.length > 0 && (
                      <div className="sm:col-span-2">
                        <span className="text-xs text-muted-foreground/60 uppercase tracking-wider block mb-2">Personagens</span>
                        <div className="flex flex-wrap gap-2">
                          {article.metadata.characters.map((c) => (
                            <span
                              key={c}
                              className="text-xs px-2.5 py-1 rounded-full bg-muted border border-border text-foreground font-medium"
                            >
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* Context */}
              <motion.section
                custom={1}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
              >
                <h2
                  className="text-lg font-bold text-foreground mb-4 flex items-center gap-3"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  <span className="w-1 h-5 bg-primary rounded-full shrink-0" />
                  Contexto
                </h2>
                <div className="text-muted-foreground leading-relaxed space-y-3">
                  {article.context.split("\n").filter(Boolean).map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </motion.section>

              {/* Quote */}
              {article.quote && (
                <motion.section
                  custom={2}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <h2
                    className="text-lg font-bold text-foreground mb-4 flex items-center gap-3"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    <span className="w-1 h-5 bg-primary rounded-full shrink-0" />
                    Fala Registrada
                  </h2>
                  <blockquote className="relative pl-6 border-l-2 border-primary/60">
                    <div className="absolute -left-3 top-0 w-5 h-5 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center">
                      <span className="text-primary text-xs font-bold">"</span>
                    </div>
                    <p className="text-lg sm:text-xl text-foreground italic leading-relaxed font-medium">
                      {article.quote}
                    </p>
                    {article.quoteSource && (
                      <footer className="mt-4 text-sm text-muted-foreground/70 not-italic">
                        — {article.quoteSource}
                      </footer>
                    )}
                  </blockquote>
                </motion.section>
              )}

              {/* Meaning */}
              <motion.section
                custom={3}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
              >
                <h2
                  className="text-lg font-bold text-foreground mb-4 flex items-center gap-3"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  <span className="w-1 h-5 bg-primary rounded-full shrink-0" />
                  Significado
                </h2>
                <div className="text-muted-foreground leading-relaxed space-y-3">
                  {article.meaning.split("\n").filter(Boolean).map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </motion.section>

              {/* Curiosity */}
              {article.curiosity && (
                <motion.section
                  custom={4}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <h2
                    className="text-lg font-bold text-foreground mb-4 flex items-center gap-3"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    <span className="w-1 h-5 bg-primary rounded-full shrink-0" />
                    Curiosidade
                  </h2>
                  <div className="bg-muted/30 border border-border rounded-xl p-5">
                    <div className="text-muted-foreground leading-relaxed space-y-3">
                      {article.curiosity.split("\n").filter(Boolean).map((p, i) => (
                        <p key={i}>{p}</p>
                      ))}
                    </div>
                    {article.metadata.anime && article.metadata.episode && article.metadata.timestamp && (
                      <div className="mt-4 pt-4 border-t border-border flex flex-wrap gap-3">
                        <span className="text-xs font-mono px-2.5 py-1 rounded bg-background border border-border text-muted-foreground">
                          {article.metadata.anime}
                        </span>
                        <span className="text-xs font-mono px-2.5 py-1 rounded bg-primary/10 border border-primary/30 text-primary">
                          Episódio {article.metadata.episode}
                        </span>
                        <span className="text-xs font-mono px-2.5 py-1 rounded bg-primary/10 border border-primary/30 text-primary">
                          {article.metadata.timestamp}
                        </span>
                      </div>
                    )}
                  </div>
                </motion.section>
              )}

              {/* Origin story */}
              {article.originStory && (
                <motion.section
                  custom={5}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <div className="relative">
                    <div className="flex items-center gap-4 mb-8">
                      <div className="h-px flex-1 bg-border" />
                      <span
                        className="text-primary text-xs font-bold tracking-widest uppercase px-1"
                        style={{ fontFamily: "'Cinzel', serif" }}
                      >
                        Todo grande arquivo começa com uma descoberta.
                      </span>
                      <div className="h-px flex-1 bg-border" />
                    </div>

                    <div className="bg-card border border-primary/20 rounded-2xl overflow-hidden">
                      <div className="px-6 py-3 bg-primary/8 border-b border-primary/20">
                        <span className="text-xs font-bold text-primary tracking-widest uppercase" style={{ fontFamily: "'Cinzel', serif" }}>
                          A Origem do Arquivo
                        </span>
                      </div>
                      <div className="p-6 sm:p-8 space-y-5">
                        {article.originStory.split("\n\n").filter(Boolean).map((block, i) => {
                          const isQuote =
                            block.startsWith('"') || block.startsWith('"');
                          const isRef =
                            block.startsWith("Anime:") ||
                            block.startsWith("Naquele momento");
                          if (isQuote) {
                            return (
                              <blockquote
                                key={i}
                                className="border-l-2 border-primary/50 pl-4 italic text-muted-foreground"
                              >
                                {block}
                              </blockquote>
                            );
                          }
                          if (isRef) {
                            return (
                              <div
                                key={i}
                                className="bg-muted/40 rounded-lg px-4 py-3 text-sm text-muted-foreground font-mono border border-border"
                              >
                                {block}
                              </div>
                            );
                          }
                          return (
                            <p key={i} className="text-muted-foreground leading-relaxed">
                              {block}
                            </p>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </motion.section>
              )}
            </div>

            {/* @section: article-sidebar */}
            <aside className="space-y-6">
              {/* Characters */}
              <div className="bg-card border border-border rounded-xl p-5 sticky top-20">
                <h3
                  className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  Personagens
                </h3>
                <div className="space-y-2">
                  {article.metadata.characters.map((c) => (
                    <div
                      key={c}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/30 border border-border"
                    >
                      <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                        <User size={12} className="text-primary" />
                      </div>
                      <span className="text-sm font-medium text-foreground">{c}</span>
                    </div>
                  ))}
                </div>

                {/* Tags */}
                {article.metadata.tags.length > 0 && (
                  <div className="mt-6 pt-5 border-t border-border">
                    <h3
                      className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3"
                      style={{ fontFamily: "'Cinzel', serif" }}
                    >
                      Tags
                    </h3>
                    <div className="flex flex-wrap gap-1.5">
                      {article.metadata.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-[11px] px-2 py-1 rounded bg-muted/50 border border-border text-muted-foreground"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Source info */}
                <div className="mt-6 pt-5 border-t border-border">
                  <h3
                    className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    Fonte
                  </h3>
                  <div className="space-y-2 text-xs text-muted-foreground/70">
                    {article.metadata.anime && (
                      <div className="flex items-center gap-2">
                        <Clock size={11} className="text-primary shrink-0" />
                        <span>{article.metadata.anime}</span>
                      </div>
                    )}
                    {article.metadata.episode !== undefined && (
                      <div className="flex items-center gap-2">
                        <ExternalLink size={11} className="text-primary shrink-0" />
                        <span>Episódio {article.metadata.episode}</span>
                      </div>
                    )}
                    {article.metadata.manga && (
                      <div className="flex items-center gap-2">
                        <BookOpen size={11} className="text-primary shrink-0" />
                        <span>{article.metadata.manga}</span>
                      </div>
                    )}
                    {article.metadata.chapter !== undefined && (
                      <div className="flex items-center gap-2">
                        <Tag size={11} className="text-primary shrink-0" />
                        <span>Capítulo {article.metadata.chapter}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </aside>
          </div>

          {/* @section: related-articles */}
          {related.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mt-16 pt-12 border-t border-border"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="h-px w-8 bg-primary/40" />
                <span
                  className="text-xs font-bold tracking-widest text-muted-foreground uppercase"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  Artigos Relacionados
                </span>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {related.map((a, i) => (
                  <ArticleCard key={a.id} article={a} index={i} />
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
