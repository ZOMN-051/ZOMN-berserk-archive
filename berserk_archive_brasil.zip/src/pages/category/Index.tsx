/* @section: category-page */
import { motion } from "framer-motion";
import ArticleCard from "@/components/ArticleCard";
import SearchBar from "@/components/SearchBar";
import { articles } from "@/data/articles";
import type { ContentCategory } from "@/lib/types";

const categoryTitles: Record<string, string> = {
  frase: "Frases",
  personagem: "Personagens",
  episodio: "Episódios",
  capitulo: "Mangá",
  curiosidade: "Curiosidades",
  simbolismo: "Simbolismos",
  cena: "Linha do Tempo",
};

const categoryDescriptions: Record<string, string> = {
  frase: "Diálogos e falas marcantes registrados com referência exata.",
  personagem: "Fichas e perfis detalhados dos personagens de Berserk.",
  episodio: "Momentos organizados por episódio do anime.",
  capitulo: "Referências e momentos indexados pelo mangá.",
  curiosidade: "Descobertas, investigações e fatos que os fãs precisam conhecer.",
  simbolismo: "Análises dos símbolos, temas e camadas de significado.",
  cena: "Os grandes eventos de Berserk em ordem cronológica.",
};

interface CategoryPageProps {
  category: ContentCategory;
  label?: string;
}

export default function CategoryPage({ category, label }: CategoryPageProps) {
  const filtered = articles.filter((a) =>
    a.metadata.categories.includes(category)
  );
  const title = label || categoryTitles[category] || category;
  const description = categoryDescriptions[category] || "";

  return (
    <div className="min-h-screen px-4 lg:px-12 py-12">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-10 bg-primary/50" />
            <span
              className="text-primary text-[10px] font-bold tracking-[0.3em] uppercase"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Berserk Archive Brasil
            </span>
          </div>
          <h1
            className="text-3xl sm:text-4xl font-bold text-foreground mb-3"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            {title}
          </h1>
          {description && (
            <p className="text-muted-foreground leading-relaxed max-w-xl">{description}</p>
          )}
        </motion.div>

        <div className="mb-10">
          <SearchBar />
        </div>

        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((article, i) => (
              <ArticleCard key={article.id} article={article} index={i} />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-24"
          >
            <div
              className="text-5xl font-bold text-primary/20 mb-4"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              B
            </div>
            <p className="text-muted-foreground mb-2">Nenhum artigo nesta categoria ainda.</p>
            <p className="text-sm text-muted-foreground/60">
              Este arquivo está em crescimento. Mais conteúdo em breve.
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
