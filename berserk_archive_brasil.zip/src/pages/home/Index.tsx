/* @section: home-page */
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Clock, Quote, Star, Users } from "lucide-react";
import SearchBar from "@/components/SearchBar";
import ArticleCard from "@/components/ArticleCard";
import { articles, getFeaturedArticle } from "@/data/articles";

const LOGO_URL =
  "https://skyagent-artifacts.skywork.ai/router/agent/2026-07-01/prod_agent_019f1be7-5042-7162-8a5c-2b41a5734e84/IMG_6541_cf4b9c4f27f547e38f153cc24b13a455.png";

const HERO_BG =
  "https://agents-download.skywork.ai/image/rt/5e2a29d70c4a370829e136e4bce4098f.jpg";

const stats = [
  { value: "6+", label: "Artigos", icon: BookOpen },
  { value: "3", label: "Personagens", icon: Users },
  { value: "2", label: "Frases Registradas", icon: Quote },
  { value: "1997", label: "Anime Clássico", icon: Clock },
];

const categories = [
  { label: "Frases", href: "/frases", description: "Diálogos e falas marcantes" },
  { label: "Personagens", href: "/personagens", description: "Fichas e perfis detalhados" },
  { label: "Episódios", href: "/episodios", description: "Referências por episódio" },
  { label: "Curiosidades", href: "/curiosidades", description: "Descobertas e investigações" },
  { label: "Simbolismos", href: "/simbolismos", description: "Análises temáticas" },
  { label: "Linha do Tempo", href: "/linha-do-tempo", description: "Cronologia dos eventos" },
];

export default function HomePage() {
  const featured = getFeaturedArticle();
  const otherArticles = articles.filter((a) => !a.featured).slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* @section: hero */}
      <section className="relative overflow-hidden min-h-[75vh] flex flex-col justify-end">
        {/* Background */}
        <div className="absolute inset-0">
          <img
            src={HERO_BG}
            alt="Berserk background"
            className="w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/65 to-background" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-transparent to-background/50" />
        </div>

        {/* Gold line top */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

        <div className="relative z-10 px-4 lg:px-12 pb-14 pt-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="max-w-3xl"
          >
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-12 bg-primary/60" />
              <span
                className="text-primary text-[10px] font-bold tracking-[0.3em] uppercase"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Arquivo de Fãs · Since 2024
              </span>
            </div>

            {/* Logo + title */}
            <div className="flex flex-col sm:flex-row sm:items-end gap-4 mb-5">
              <img
                src={LOGO_URL}
                alt="BERSERK"
                className="h-14 sm:h-16 object-contain object-left"
                style={{ filter: "drop-shadow(0 2px 12px oklch(0.65 0.14 50 / 0.3))" }}
              />
              <div className="sm:pb-1">
                <span
                  className="block text-xl sm:text-2xl font-bold text-muted-foreground tracking-[0.15em] uppercase"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  Archive Brasil
                </span>
              </div>
            </div>

            {/* Subtitle */}
            <p className="text-sm sm:text-base text-muted-foreground leading-relaxed mb-10 max-w-xl border-l-2 border-primary/40 pl-4">
              Um arquivo criado por fãs para preservar os momentos mais marcantes de Berserk —
              frases, cenas, simbolismos e curiosidades, com referência exata ao anime e ao mangá.
            </p>

            {/* Search */}
            <SearchBar large />
          </motion.div>
        </div>
      </section>

      {/* @section: stats */}
      <section className="px-4 lg:px-12 py-8 border-y border-border bg-card/30">
        <div className="max-w-5xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="text-center"
            >
              <div
                className="text-2xl sm:text-3xl font-bold text-primary mb-1"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                {s.value}
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* @section: featured-article */}
      {featured && (
        <section className="px-4 lg:px-12 py-14">
          <div className="max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="flex items-center gap-2">
                <Star size={13} className="text-primary fill-primary" />
                <span
                  className="text-primary text-[10px] font-bold tracking-[0.25em] uppercase"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  Artigo em Destaque
                </span>
              </div>
              <div className="h-px flex-1 bg-border" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
            >
              <Link
                to={`/artigo/${featured.slug}`}
                className="group block bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/50 transition-all duration-300 hover:shadow-[0_16px_50px_-12px_oklch(0.65_0.14_50_/_0.18)]"
              >
                <div className="grid lg:grid-cols-[1fr_1.1fr] gap-0">
                  {/* Image */}
                  <div className="relative aspect-[4/3] lg:aspect-auto overflow-hidden">
                    {featured.image && (
                      <img
                        src={featured.image}
                        alt={featured.title}
                        className="w-full h-full object-cover opacity-75 transition-transform duration-700 group-hover:scale-105"
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-card/80 via-transparent to-transparent lg:hidden" />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-card/40 hidden lg:block" />
                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex gap-2 flex-wrap">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-background/80 border border-primary/40 text-primary backdrop-blur-sm font-mono">
                        Ep. {featured.metadata.episode}
                      </span>
                      {featured.metadata.timestamp && (
                        <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-background/80 border border-border text-muted-foreground backdrop-blur-sm">
                          {featured.metadata.timestamp}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-7 lg:p-10 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-primary/30 bg-primary/10 text-primary tracking-widest uppercase">
                        Frase
                      </span>
                      <span className="text-xs text-muted-foreground/60">{featured.metadata.anime}</span>
                    </div>

                    <h2
                      className="text-xl sm:text-2xl font-bold text-foreground group-hover:text-primary transition-colors duration-300 mb-4 leading-snug"
                      style={{ fontFamily: "'Cinzel', serif" }}
                    >
                      {featured.title}
                    </h2>

                    {featured.quote && (
                      <blockquote className="border-l-2 border-primary/50 pl-4 mb-5">
                        <p className="text-sm text-muted-foreground italic leading-relaxed line-clamp-3">
                          "{featured.quote}"
                        </p>
                      </blockquote>
                    )}

                    <p className="text-sm text-muted-foreground/70 leading-relaxed mb-6 line-clamp-2">
                      {featured.excerpt}
                    </p>

                    <div className="flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all duration-200">
                      <span>Ler artigo completo</span>
                      <ArrowRight size={14} />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          </div>
        </section>
      )}

      {/* @section: categories */}
      <section className="px-4 lg:px-12 py-12 bg-muted/15 border-y border-border">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="flex items-center gap-4 mb-7"
          >
            <div className="h-px w-8 bg-primary/40" />
            <span
              className="text-[10px] font-bold tracking-[0.25em] text-muted-foreground uppercase"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Explorar por Categoria
            </span>
          </motion.div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.label}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.06 }}
              >
                <Link
                  to={cat.href}
                  className="group block p-4 bg-card border border-border rounded-xl hover:border-primary/40 hover:bg-card/80 transition-all duration-200 text-center h-full"
                >
                  <div
                    className="text-sm font-bold text-foreground group-hover:text-primary transition-colors duration-200 mb-1"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    {cat.label}
                  </div>
                  <div className="text-[11px] text-muted-foreground/60 leading-snug">{cat.description}</div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* @section: recent-articles */}
      <section className="px-4 lg:px-12 py-14">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-8"
          >
            <div className="flex items-center gap-4">
              <div className="h-px w-8 bg-primary/40" />
              <span
                className="text-[10px] font-bold tracking-[0.25em] text-muted-foreground uppercase"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Outros Artigos
              </span>
            </div>
            <Link
              to="/frases"
              className="text-xs text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
            >
              Ver todos <ArrowRight size={12} />
            </Link>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {otherArticles.map((article, i) => (
              <ArticleCard key={article.id} article={article} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* @section: about-callout */}
      <section className="px-4 lg:px-12 py-16 bg-card/30 border-t border-border">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {/* Logo small */}
            <img
              src={LOGO_URL}
              alt="Berserk"
              className="h-8 object-contain mx-auto mb-6 opacity-60"
            />
            <h2
              className="text-2xl sm:text-3xl font-bold text-foreground mb-5 leading-snug"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Todo grande arquivo começa<br className="hidden sm:block" /> com uma descoberta.
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-3">
              O Berserk Archive Brasil nasceu de uma simples pergunta:{" "}
              <em className="text-foreground">"Em que episódio o Judeau fala isso?"</em>
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8 text-sm">
              O que parecia uma resposta fácil se tornou uma investigação. Depois de revisar episódios, fóruns
              e transcrições, a cena foi encontrada — Berserk (1997), Episódio 19, aos 07:18. E com essa
              descoberta, surgiu a ideia de que nenhum outro momento marcante deveria ficar perdido.
            </p>
            <Link
              to="/sobre"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-primary/40 text-primary text-sm font-medium hover:bg-primary/10 transition-all duration-200"
            >
              Ler a história completa
              <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
