/* @section: sobre-page */
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const LOGO_URL =
  "https://skyagent-artifacts.skywork.ai/router/agent/2026-07-01/prod_agent_019f1be7-5042-7162-8a5c-2b41a5734e84/IMG_6541_cf4b9c4f27f547e38f153cc24b13a455.png";

const blocks = [
  {
    type: "paragraph",
    text: "Durante muito tempo, uma frase do personagem Judeau circulou pela internet sem uma referência clara ao anime. Muitos fãs a atribuíam apenas ao mangá, enquanto outros juravam tê-la visto na adaptação clássica de 1997.",
  },
  {
    type: "paragraph",
    text: 'Em uma conversa entre dois fãs de Berserk, surgiu uma discussão simples:',
  },
  {
    type: "quote",
    text: '"Em que episódio o Judeau fala isso?"',
  },
  {
    type: "paragraph",
    text: "A resposta parecia impossível de encontrar.",
  },
  {
    type: "paragraph",
    text: "Foram pesquisados episódios, transcrições, bancos de citações e fóruns, mas ninguém conseguia apontar exatamente onde a cena acontecia. Mesmo assim, um dos fãs insistiu:",
  },
  {
    type: "quote",
    text: '"Eu tenho certeza que vi. Foi no clássico de 1997."',
  },
  {
    type: "paragraph",
    text: "Depois de revisar os episódios um por um, finalmente a cena foi encontrada.",
  },
  {
    type: "ref",
    items: ["Anime: Berserk (1997)", "Episódio: 19", "Minutagem: aproximadamente 07:18 (versão disponível na Netflix)"],
  },
  {
    type: "paragraph",
    text: "Naquele momento, Judeau diz:",
  },
  {
    type: "blockquote",
    text: '"Eu sempre fui do tipo que conseguia fazer praticamente qualquer coisa com perfeição. Eu era melhor com as espadas e facas do que a maioria e eu sempre fui perspicaz. Mas nunca fui o melhor em nada."',
  },
  {
    type: "paragraph",
    text: "A partir dessa descoberta nasceu a ideia deste projeto.",
  },
];

export default function SobrePage() {
  return (
    <div className="min-h-screen px-4 lg:px-12 py-14">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-14 text-center"
        >
          <img src={LOGO_URL} alt="Berserk" className="h-10 object-contain mx-auto mb-8 opacity-70" />
          <div className="flex items-center gap-4 mb-6">
            <div className="h-px flex-1 bg-border" />
            <span
              className="text-primary text-[10px] font-bold tracking-[0.3em] uppercase"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              A Origem do Arquivo
            </span>
            <div className="h-px flex-1 bg-border" />
          </div>
          <h1
            className="text-3xl sm:text-4xl font-bold text-foreground leading-tight"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            Todo grande arquivo começa<br />com uma descoberta.
          </h1>
        </motion.div>

        {/* Story */}
        <div className="space-y-6">
          {blocks.map((block, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-30px" }}
              transition={{ duration: 0.45, delay: i * 0.04 }}
            >
              {block.type === "paragraph" && (
                <p className="text-muted-foreground leading-relaxed text-base">{block.text}</p>
              )}
              {block.type === "quote" && (
                <p className="text-lg text-foreground italic pl-6 border-l-2 border-primary/40">
                  {block.text}
                </p>
              )}
              {block.type === "blockquote" && (
                <blockquote className="bg-card border border-primary/20 rounded-xl p-6 relative">
                  <div className="absolute -top-3 left-6 w-6 h-6 rounded-full bg-background border border-primary/40 flex items-center justify-center">
                    <span className="text-primary text-xs font-bold">"</span>
                  </div>
                  <p className="text-foreground text-base sm:text-lg italic leading-relaxed font-medium">
                    {block.text}
                  </p>
                </blockquote>
              )}
              {block.type === "ref" && block.items && (
                <div className="bg-muted/30 border border-border rounded-lg px-5 py-4 space-y-1.5">
                  {block.items.map((item, j) => (
                    <div key={j} className="text-sm font-mono text-muted-foreground">
                      {item}
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Closing */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-14 pt-12 border-t border-border text-center space-y-5"
        >
          <p className="text-muted-foreground leading-relaxed">
            O{" "}
            <span className="text-foreground font-semibold">Berserk Archive Brasil</span>{" "}
            existe para que nenhuma outra cena marcante da obra fique perdida entre lembranças,
            dúvidas ou informações incompletas.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Este arquivo foi criado por fãs, para fãs, com o objetivo de preservar os momentos
            que fizeram de Berserk uma das maiores obras já escritas.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <Link
              to="/artigo/judeau-nunca-fui-o-melhor-em-nada"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary/10 border border-primary/40 text-primary text-sm font-medium hover:bg-primary/20 transition-all duration-200"
            >
              Ler o primeiro artigo
              <ArrowRight size={14} />
            </Link>
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-muted-foreground text-sm font-medium hover:border-primary/40 hover:text-foreground transition-all duration-200"
            >
              Voltar ao arquivo
            </Link>
          </div>
        </motion.div>

        {/* Footer note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-12 text-xs text-muted-foreground/50 text-center leading-relaxed"
        >
          Este projeto é uma homenagem feita por fãs. Berserk e seus personagens pertencem a Kentaro Miura
          e aos respectivos detentores dos direitos autorais. Este site possui finalidade exclusivamente
          informativa e educativa.
        </motion.p>
      </div>
    </div>
  );
}
